const express = require("express");
const { dirname } = require("path");

// http: createServer() ; using express:
const server = express();
const path = require("path")


// // page: dynamic variable
// server.get("/:page", function(req,res) {
//     const { page } = req.params;
//     res.send(page);
    
// });

// set templating engine
server.set("view engine", "ejs");
// default loc of templating engine views
server.set("views", path.resolve(__dirname, "app/views"));
    // res.send("Home");

// express static. goes over every file in this folder and adds them. css, js,...
server.use(express.static(path.resolve(__dirname, "assets")));


// routing
server.get("/", function(req,res) {
    // res.send("Home");
    res.render("pages/index");
});


server.get("/students", function(req,res) {
    // res.send("Home");
    res.render("pages/students");
});

// any page that was not defined previously (fallback)
server.use("*", function(req,res) {
    res.send("Error 404");
});



const port = 3000 ;
// start server
server.listen(port, function () {
    console.log(`Server Running at http://localhost:${port}`);
});