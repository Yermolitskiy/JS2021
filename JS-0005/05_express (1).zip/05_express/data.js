const data = [
    {
        name: 'Emils',
        age: 29,
        gender: 'male',
    },
    {
        name: 'John',
        age: 33,
        gender: 'male'
    }
];

exports.module = data;